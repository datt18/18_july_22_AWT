$(document).ready(function(){
    $("#sortable-10").sortable();

    $("#sortable-11").sortable();

    $("#sortable-10").sortable({
       connectwith:"#sortable-11,#sortable-10"

    });
    $("sortable-11").sotable({
        connectwith:"#sortable-10,sortable-11"
    });

});